import React from 'react';
import SectionWrapper from './SectionWrapper';
import { INTERNSHIP } from '../constants';
import { BriefcaseIcon } from './icons/FeatureIcons';

const Experience: React.FC = () => {
  return (
    <SectionWrapper
      id="experience"
      subtitle="Professional Path"
      title="Internship Experience"
      className="bg-light-bg"
    >
      <div className="max-w-3xl mx-auto">
        <div className="bg-light-secondary-bg p-8 rounded-lg shadow-lg">
          <div className="flex items-start space-x-6">
            <BriefcaseIcon className="w-12 h-12 text-accent flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-2xl font-bold text-dark-text">{INTERNSHIP.role}</h3>
              <p className="text-primary font-semibold mt-1">{INTERNSHIP.company}</p>
              <p className="text-subtle-text text-sm my-2">{INTERNSHIP.duration}</p>
              <p className="text-subtle-text">{INTERNSHIP.description}</p>
            </div>
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
};

export default Experience;