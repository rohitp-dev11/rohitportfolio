import React from 'react';
import SectionWrapper from './SectionWrapper';
import { PROJECTS } from '../constants';
import type { Project } from '../types';
import { GithubIcon } from './icons/SocialIcons';
import { ExternalLinkIcon } from './icons/FeatureIcons';

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
  return (
    <div className="bg-light-bg rounded-lg overflow-hidden shadow-lg flex flex-col group transform hover:-translate-y-2 transition-all duration-300 hover:shadow-xl">
      <div className="relative overflow-hidden h-56">
        <img src={project.imageUrl} alt={project.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-dark-text mb-2">{project.title}</h3>
        <p className="text-subtle-text mb-4 text-sm flex-grow">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags.map(tag => (
            <span key={tag} className="bg-gray-200 text-primary text-xs font-semibold px-2.5 py-1 rounded-full">{tag}</span>
          ))}
        </div>
        <div className="flex items-center space-x-4 mt-auto pt-4 border-t border-gray-200">
          {project.liveUrl && (
            <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:text-accent font-semibold transition-colors">
              <ExternalLinkIcon className="w-5 h-5 mr-2" />
              Live Demo
            </a>
          )}
          {project.sourceUrl && (
            <a href={project.sourceUrl} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:text-accent font-semibold transition-colors">
              <GithubIcon className="w-5 h-5 mr-2" />
              Source Code
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

const Projects: React.FC = () => {
  return (
    <SectionWrapper
      id="projects"
      subtitle="Portfolio"
      title="Featured Projects"
      className="bg-light-secondary-bg"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PROJECTS.map((project) => (
          <ProjectCard key={project.title} project={project} />
        ))}
      </div>
    </SectionWrapper>
  );
};

export default Projects;