
import React, { useState, useEffect } from 'react';
import { PERSONAL_INFO, SOCIAL_LINKS } from '../constants';
import { PlayIcon } from './icons/FeatureIcons';

const Hero: React.FC = () => {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsMounted(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 100; // As used in Header.tsx
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center bg-light-bg px-4 sm:px-6 lg:px-8 overflow-hidden pt-28 sm:pt-20">
      <div className="max-w-6xl mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className={`text-center md:text-left transition-all duration-1000 ease-out ${isMounted ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            <p className="text-lg font-semibold text-accent tracking-wider uppercase">Hello There!</p>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-dark-text tracking-tight mt-2">
              I'm <span className="text-primary">{PERSONAL_INFO.name}</span>,
            </h1>
            <h2 className="text-3xl md:text-4xl font-bold text-dark-text mt-2">{PERSONAL_INFO.shortTitle}</h2>
            <p className="mt-4 text-lg text-subtle-text max-w-lg mx-auto md:mx-0">
              {PERSONAL_INFO.introduction}
            </p>
            
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
              <a
                href="#projects"
                onClick={(e) => handleScrollTo(e, 'projects')}
                className="flex items-center gap-2 px-6 py-3 bg-accent text-primary font-bold rounded-full shadow-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105"
              >
                <PlayIcon className="w-6 h-6"/>
                View My Work
              </a>
              <a
                href={SOCIAL_LINKS.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 border-2 border-primary text-primary font-bold rounded-full shadow-lg hover:bg-primary hover:text-light-text transition-all duration-300 transform hover:scale-105"
              >
                Hire Me
              </a>
            </div>
          </div>
          
          <div className={`relative flex justify-center items-center transition-all duration-1000 ease-out delay-200 ${isMounted ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
            <div className="absolute w-full h-full max-w-md">
                <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className="absolute w-full h-full text-accent/80 -z-10 transform scale-125">
                    <path fill="currentColor" d="M49.3,-58.5C62.6,-49,71.2,-33.4,75.1,-16.4C79,0.7,78.2,19.2,69.5,33.5C60.8,47.8,44.2,57.9,27.5,65.1C10.8,72.3,-6.1,76.6,-22.4,72.4C-38.7,68.2,-54.5,55.5,-64.2,39.9C-73.9,24.3,-77.6,5.8,-73.9,-10.8C-70.2,-27.4,-59.1,-42.1,-46.1,-52.1C-33.1,-62.1,-18.2,-67.4,-1.8,-65.9C14.5,-64.4,29.1,-66.6,40.3,-63.9C51.5,-61.2,55.7,-53.9,49.3,-58.5Z" transform="translate(100 100) scale(1.1)" />
                </svg>
            </div>
            
            {/* Pulsing Glow Effect */}
            <div className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full animate-pulse-shadow"></div>
            
             <img
                src="https://raw.githubusercontent.com/rohitp-dev11/Rohit_Profile/main/WhatsApp%20Image%202025-10-13%20at%2022%2C09%2C09_0442d02e-photoaidcom-cropped.jpg"
                alt="Rohit P"
                className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-full object-cover border-4 border-light-bg shadow-2xl z-10"
             />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
