
import React from 'react';
import { SOCIAL_LINKS, PERSONAL_INFO } from '../constants';
import { GithubIcon, LinkedinIcon, MailIcon } from './icons/SocialIcons';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary border-t border-accent/20 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-light-text/70">
        <div className="flex justify-center space-x-6 mb-4">
          <a href={SOCIAL_LINKS.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <GithubIcon className="w-6 h-6" />
          </a>
          <a href={SOCIAL_LINKS.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <LinkedinIcon className="w-6 h-6" />
          </a>
          <a href={SOCIAL_LINKS.email} aria-label="Email" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <MailIcon className="w-6 h-6" />
          </a>
        </div>
        <p>&copy; {new Date().getFullYear()} {PERSONAL_INFO.name}. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;