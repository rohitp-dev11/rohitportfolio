import React, { useState, useEffect, useRef } from 'react';

interface SectionWrapperProps {
  id: string;
  title: string;
  subtitle: string;
  children: React.ReactNode;
  className?: string;
}

const SectionWrapper: React.FC<SectionWrapperProps> = ({ id, title, subtitle, children, className = '' }) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // Animate only once
        }
      },
      {
        threshold: 0.1, // Trigger when 10% of the element is visible
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (observer) {
        observer.disconnect();
      }
    };
  }, []);

  return (
    <section 
      id={id} 
      className={`py-20 md:py-28 px-4 sm:px-6 lg:px-8 overflow-hidden ${className}`}
    >
      <div ref={sectionRef} className="max-w-6xl mx-auto">
        <div className={`mb-12 md:mb-16 text-center transition-all duration-700 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
          <h3 className="text-lg font-semibold text-accent mb-2 tracking-wider uppercase">{subtitle}</h3>
          <h2 className="text-3xl md:text-4xl font-bold text-dark-text tracking-tight">
            {title}
          </h2>
        </div>
        <div className={`transition-all duration-700 ease-out ${isVisible ? 'opacity-100 translate-y-0 delay-200' : 'opacity-0 translate-y-5'}`}>
          {children}
        </div>
      </div>
    </section>
  );
};

export default SectionWrapper;