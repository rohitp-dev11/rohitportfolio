import React from 'react';
import SectionWrapper from './SectionWrapper';
import { SERVICES, SOCIAL_LINKS } from '../constants';
import type { Service } from '../types';

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => {
  return (
    <div className="bg-light-bg p-8 rounded-lg shadow-lg text-left group transform hover:-translate-y-2 transition-all duration-300 hover:shadow-xl">
      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-accent/20 mb-6 transition-transform duration-300 group-hover:scale-110">
        {service.icon}
      </div>
      <h3 className="text-xl font-bold text-dark-text mb-3">{service.title}</h3>
      <p className="text-subtle-text mb-4">{service.description}</p>
      <a 
        href={SOCIAL_LINKS.linkedin}
        target="_blank"
        rel="noopener noreferrer"
        className="font-bold text-primary hover:text-accent transition-colors duration-300"
      >
        Learn more &rarr;
      </a>
    </div>
  );
};

const Services: React.FC = () => {
  return (
    <SectionWrapper
      id="services"
      subtitle="Services"
      title="Services I Provide"
      className="bg-light-secondary-bg"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {SERVICES.map((service) => (
          <ServiceCard key={service.title} service={service} />
        ))}
      </div>
    </SectionWrapper>
  );
};

export default Services;