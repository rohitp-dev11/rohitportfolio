
import React, { useState, useEffect } from 'react';
import { ArrowUpIcon } from './icons/FeatureIcons';

const ScrollToTop: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  const toggleVisibility = () => {
    if (window.scrollY > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, []);

  return (
    <button
      type="button"
      onClick={scrollToTop}
      className={`fixed bottom-8 right-8 z-50 p-3 rounded-full bg-accent text-primary shadow-lg transition-opacity duration-300 transform hover:-translate-y-1 hover:shadow-xl ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      aria-label="Go to top"
    >
      <ArrowUpIcon className="w-6 h-6" strokeWidth={3} />
    </button>
  );
};

export default ScrollToTop;
