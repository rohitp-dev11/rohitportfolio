import React from 'react';
import SectionWrapper from './SectionWrapper';
import { TECHNICAL_SKILLS, CREATIVE_SKILLS, PROFESSIONAL_SKILLS } from '../constants';

const SkillBar: React.FC<{ name: string; level: number; }> = ({ name, level }) => {
  return (
    <div className="mb-6">
      <div className="flex justify-between mb-1">
        <span className="text-base font-medium text-dark-text">{name}</span>
        <span className="text-sm font-medium text-primary">{level}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div
          className="bg-accent h-2.5 rounded-full"
          style={{ width: `${level}%` }}
        ></div>
      </div>
    </div>
  );
};

const Skills: React.FC = () => {
  return (
    <SectionWrapper
      id="skills"
      subtitle="My Skills"
      title="Expertise & Proficiencies"
      className="bg-light-bg"
    >
      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
        <div>
          <h3 className="text-2xl font-semibold text-dark-text mb-6 border-b-2 border-accent/30 pb-2">Technical Skills</h3>
          {TECHNICAL_SKILLS.map((skill) => (
            <SkillBar key={skill.name} name={skill.name} level={skill.level} />
          ))}
        </div>
        
        <div className="space-y-8">
           <div>
            <h3 className="text-2xl font-semibold text-dark-text mb-6 border-b-2 border-accent/30 pb-2">Creative Skills</h3>
            {CREATIVE_SKILLS.map((skill) => (
              <SkillBar key={skill.name} name={skill.name} level={skill.level} />
            ))}
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold text-dark-text mb-6 border-b-2 border-accent/30 pb-2">Professional Skills</h3>
            {PROFESSIONAL_SKILLS.map((skill) => (
              <SkillBar key={skill.name} name={skill.name} level={skill.level} />
            ))}
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
};

export default Skills;