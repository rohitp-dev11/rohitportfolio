import React, { useState, useEffect } from 'react';
import { PERSONAL_INFO } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeLink, setActiveLink] = useState('#home');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('section[id]');
      let current = '#home';
      sections.forEach(section => {
        const sectionTop = (section as HTMLElement).offsetTop;
        if (window.scrollY >= sectionTop - 100) {
          current = `#${section.id}`;
        }
      });
      setActiveLink(current);
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);

    if (targetElement) {
      const headerOffset = 100; // Offset for the fixed header
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });

      // Close mobile menu if open
      setIsMenuOpen(false);
    }
  };

  const navLinks = [
    { href: '#home', label: 'Home' },
    { href: '#about', label: 'About' },
    { href: '#education', label: 'Education' },
    { href: '#experience', label: 'Experience' },
    { href: '#services', label: 'Services' },
    { href: '#skills', label: 'Skills' },
    { href: '#projects', label: 'Projects' },
  ];

  return (
    <header className={`fixed top-4 sm:top-6 left-1/2 -translate-x-1/2 z-50 w-[90%] transition-all duration-300 px-6 py-3 rounded-full ${isScrolled ? 'bg-primary/90 backdrop-blur-sm shadow-2xl' : 'bg-primary shadow-xl'} flex justify-between items-center xl:relative xl:justify-center`}>
      
      {/* Left: Logo */}
      <div className="xl:absolute xl:left-6 xl:top-1/2 xl:-translate-y-1/2">
        <a href="#home" onClick={(e) => handleNavLinkClick(e, '#home')} className="text-xl sm:text-2xl font-bold text-light-text flex items-center">
            <span className="bg-accent text-primary w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-extrabold text-xl mr-3">R</span>
            <span className="inline">{PERSONAL_INFO.name}.</span>
        </a>
      </div>

      {/* Center: Desktop Nav */}
      <nav className="hidden xl:flex items-center space-x-4">
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleNavLinkClick(e, link.href)}
            className={`font-medium transition-colors duration-300 pb-1 px-2 text-base whitespace-nowrap ${
              activeLink === link.href
                ? 'text-accent border-b-2 border-accent'
                : 'text-light-text/90 hover:text-accent border-b-2 border-transparent'
            }`}
          >
            {link.label}
          </a>
        ))}
      </nav>
      
      {/* Right: Contact Button & Mobile Toggle */}
      <div className="flex items-center xl:absolute xl:right-6 xl:top-1/2 xl:-translate-y-1/2">
          {/* Contact Button Desktop */}
          <div className="hidden xl:flex">
            <a 
              href="#contact" 
              onClick={(e) => handleNavLinkClick(e, '#contact')}
              className="bg-light-bg text-primary font-bold py-2 px-5 rounded-full hover:bg-opacity-90 transition-all transform hover:scale-105 text-base"
            >
              Contact Me
            </a>
          </div>

          {/* Mobile Nav Toggle & Menu */}
          <div className="xl:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-light-text hover:text-accent focus:outline-none p-2">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'}></path>
              </svg>
            </button>
            
            {isMenuOpen && (
              <div className="absolute top-full mt-3 w-64 right-0 bg-primary rounded-2xl shadow-xl p-4 border border-light-text/10">
                <nav className="flex flex-col items-center space-y-2">
                  {navLinks.map((link) => (
                    <a
                      key={link.href}
                      href={link.href}
                      onClick={(e) => handleNavLinkClick(e, link.href)}
                      className={`font-medium transition-colors duration-300 w-full text-center py-2 rounded-md ${
                        activeLink === link.href ? 'text-accent bg-light-text/10' : 'text-light-text hover:text-accent'
                      }`}
                    >
                      {link.label}
                    </a>
                  ))}
                  <a
                    href="#contact"
                    onClick={(e) => handleNavLinkClick(e, '#contact')}
                    className="bg-light-bg text-primary font-bold py-2 px-6 rounded-full hover:bg-opacity-90 transition-all w-full text-center mt-2"
                  >
                    Contact Me
                  </a>
                </nav>
              </div>
            )}
          </div>
      </div>
    </header>
  );
};

export default Header;