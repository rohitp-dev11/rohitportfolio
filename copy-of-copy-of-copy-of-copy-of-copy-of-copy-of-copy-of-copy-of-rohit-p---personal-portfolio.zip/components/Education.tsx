import React from 'react';
import SectionWrapper from './SectionWrapper';
import { EDUCATION } from '../constants';
import { AcademicCapIcon } from './icons/FeatureIcons';

const Education: React.FC = () => {
  return (
    <SectionWrapper
      id="education"
      subtitle="My Journey"
      title="Education"
      className="bg-light-secondary-bg"
    >
      <div className="max-w-3xl mx-auto">
        <div className="bg-light-bg p-8 rounded-lg shadow-lg">
          <div className="flex items-start space-x-6">
            <AcademicCapIcon className="w-12 h-12 text-accent flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-2xl font-bold text-dark-text">{EDUCATION.degree}</h3>
              <p className="text-primary font-semibold mt-1">{EDUCATION.institution}</p>
              <p className="text-subtle-text text-sm mt-2">{EDUCATION.duration}</p>
            </div>
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
};

export default Education;