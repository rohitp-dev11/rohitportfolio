import React, { useState, useEffect } from 'react';
import { PERSONAL_INFO, SOCIAL_LINKS } from '../constants';
import { GithubIcon, LinkedinIcon, MailIcon } from './icons/SocialIcons';

// This will make TypeScript happy about the global emailjs object from the CDN
declare const emailjs: any;

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  // User's EmailJS credentials
  const serviceID = "service_fsqcla8";
  const templateID = "template_m5ah9x6";
  const publicKey = "En2WznTVGpHZmwN_c";

  useEffect(() => {
    if (typeof emailjs !== 'undefined') {
      emailjs.init(publicKey);
    }
  }, [publicKey]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('Sending...');

    if (typeof emailjs === 'undefined') {
        console.error("EmailJS SDK not loaded.");
        setStatus("Could not send message. EmailJS SDK failed to load.");
        return;
    }

    const templateParams = {
        name: formData.name,
        to_name: PERSONAL_INFO.name,
        from_name: formData.name,
        from_email: formData.email,
        from_message: formData.message,
        time: new Date().toLocaleString()
    };

    emailjs.send(serviceID, templateID, templateParams)
      .then((response: any) => {
        console.log('✅ SUCCESS!', response.status, response.text);
        setStatus('Thank you for your message! I will get back to you soon.');
        setFormData({ name: '', email: '', message: '' });
        setTimeout(() => setStatus(''), 5000);
      }, (error: any) => {
        console.log('❌ FAILED...', error);
        setStatus("Oops! Something went wrong. Please try again.");
        setTimeout(() => setStatus(''), 5000);
      });
  };

  return (
    <section 
      id="contact" 
      className="py-20 md:py-28 px-4 sm:px-6 lg:px-8 bg-primary text-light-text"
    >
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-12 md:mb-16">
          <h3 className="text-lg font-semibold text-accent mb-2 tracking-wider uppercase">Contact</h3>
          <h2 className="text-3xl md:text-4xl font-bold text-light-text tracking-tight">Get In Touch</h2>
        </div>

        <p className="text-lg text-light-text/80 mb-8">
          I'm always open to discussing new projects, creative ideas, or opportunities. Feel free to reach out!
        </p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-6">
            <input type="text" name="name" id="name" required placeholder="Your Name" value={formData.name} onChange={handleChange} className="w-full bg-transparent border-b-2 border-light-text/30 focus:border-accent focus:ring-0 rounded-none p-3 transition-colors text-light-text placeholder-light-text/50"/>
            <input type="email" name="email" id="email" required placeholder="Your Email" value={formData.email} onChange={handleChange} className="w-full bg-transparent border-b-2 border-light-text/30 focus:border-accent focus:ring-0 rounded-none p-3 transition-colors text-light-text placeholder-light-text/50"/>
          </div>
          <div>
            <textarea name="message" id="message" required rows={5} placeholder="Your Message" value={formData.message} onChange={handleChange} className="w-full bg-transparent border-b-2 border-light-text/30 focus:border-accent focus:ring-0 rounded-none p-3 transition-colors text-light-text placeholder-light-text/50"></textarea>
          </div>
          <div>
            <button type="submit" className="px-8 py-3 bg-accent text-primary font-bold rounded-full shadow-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 disabled:bg-gray-400 disabled:opacity-70 disabled:cursor-not-allowed" disabled={status === 'Sending...'}>
              {status === 'Sending...' ? 'Sending...' : 'Send Message'}
            </button>
          </div>
          {status && status !== 'Sending...' && <p className="text-center text-accent mt-4">{status}</p>}
        </form>
         <div className="mt-12 flex justify-center space-x-6">
          <a href={SOCIAL_LINKS.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <GithubIcon className="w-8 h-8" />
          </a>
          <a href={SOCIAL_LINKS.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <LinkedinIcon className="w-8 h-8" />
          </a>
          <a href={SOCIAL_LINKS.email} aria-label="Email" className="text-light-text/70 hover:text-accent transition-colors duration-300 transform hover:scale-110">
            <MailIcon className="w-8 h-8" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;