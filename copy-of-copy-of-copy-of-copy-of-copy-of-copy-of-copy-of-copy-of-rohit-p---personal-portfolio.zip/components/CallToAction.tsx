
import React, { useState, useEffect, useRef } from 'react';

const CallToAction: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (observer) {
        observer.disconnect();
      }
    };
  }, []);
  
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };


  return (
    <section 
      ref={sectionRef}
      className={`py-20 md:py-28 bg-primary text-light-text transition-all duration-700 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="max-w-4xl mx-auto text-center px-4">
        <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight">
          Ready to bring your
          <br />
          <span className="text-accent">ideas to life?</span>
        </h2>
        
        <div className="mt-6 h-20 flex justify-center">
           <svg viewBox="0 0 100 80" xmlns="http://www.w3.org/2000/svg" className="text-accent h-full">
              {/* "Rohit" signature from image */}
              <path 
                d="M23.6,43.3c0.3-4.5,2.4-15.8,11.7-19.4c11.2-4.4,18.9,5.5,18.9,5.5s-4.1-6.9-10.7-3.2s-7.1,12.5-6.8,16.5c0.4,4,3.7,6.4,3.7,6.4s-3.2-1.4-3.5-4.3c-0.1,0-4.1,14.2,3.2,14.7c0,0,1.1-1.4,1.1-1.4c-3.1-0.9-2.3-10.7-2.3-10.7l10.1,11.8c0,0-1.4-13.6-1.4-13.6l9,13.6c0,0-2.3-13.6,0-13.6c2.3,0,1.8,10,1.8,10l9.6-10.7c0,0,1.8,10.7,1.8,10.7l5.9-7.1 M71.8,47.3c0,0,5.9-1.4,7.7-0.9 M25.4,63.1c11.2-1.8,50.7-11.6,67.4-3.7"
                stroke="currentColor" 
                fill="transparent" 
                strokeWidth="2.5" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              />
          </svg>
        </div>
        
        <p className="mt-6 max-w-2xl mx-auto text-lg text-light-text/80">
          Whether you have a project in mind, a question, or just want to connect, I'm all ears. Let's create something exceptional together.
        </p>

        <a 
            href="#contact" 
            onClick={(e) => handleScrollTo(e, 'contact')}
            className="mt-10 inline-block bg-accent text-primary font-bold py-3 px-8 rounded-full shadow-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105"
        >
          Let's Talk
        </a>

        {/* Brush Stroke Divider */}
        <div className="mt-8 flex justify-center" aria-hidden="true">
            <svg width="120" height="12" viewBox="0 0 120 12" xmlns="http://www.w3.org/2000/svg" className="text-accent/70">
                <path 
                    d="M5 6 C 25 2, 45 10, 60 6 S 95 2, 115 6" 
                    stroke="currentColor" 
                    fill="none" 
                    strokeWidth="3" 
                    strokeLinecap="round" 
                />
            </svg>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
