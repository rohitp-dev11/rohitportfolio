import React from 'react';
import SectionWrapper from './SectionWrapper';
import { STATS } from '../constants';

const About: React.FC = () => {
  return (
    <SectionWrapper
      id="about"
      subtitle="About Me"
      title="Who is Rohit P?"
      className="bg-light-bg"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="animate-float">
           <img
                src="https://raw.githubusercontent.com/rohitp-dev11/Rohit_Profile/main/Gemini_Generated_Image_flc5dcflc5dcflc5.png"
                alt="Rohit's Profile Image"
                className="rounded-full shadow-xl w-full max-w-md mx-auto aspect-square object-cover"
            />
        </div>
        
        <div className="space-y-6 text-lg text-subtle-text">
          <p>
            I am a second-year BCA (Computer Science) student at Mar Thoma Institute of Technology with a deep-seated passion for technology and problem-solving. My journey into programming quickly evolved into a dedicated pursuit of building elegant and efficient solutions.
          </p>
          <p>
            My primary focus is on back-end development with <strong className="text-primary font-semibold">Python and Django</strong>, but I'm also deeply interested in the narratives that data can tell. This intersection of robust development and data-driven insights is where I thrive.
          </p>
          
          <div className="flex flex-wrap justify-center sm:justify-start gap-8 pt-6 border-t border-gray-200">
            {STATS.map(stat => (
              <div key={stat.label} className="text-center">
                <p className="text-4xl font-bold text-accent">{stat.value}</p>
                <p className="text-subtle-text mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
};

export default About;